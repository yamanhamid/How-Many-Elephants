// conversion logic and error handling
function convert() {
  var kmInput = document.getElementById("kmInput");
  var mileOutput = document.getElementById("mileOutput");
  var errorMsg = document.getElementById("errorMsg");
  var unitSelect = document.getElementById("unitSelect");
  
  // Get selected unit from the combo box
  var selectedUnit = unitSelect.value;

  // Check if input is negative or empty
  if (kmInput.value < 0 || kmInput.value.trim() === "") {
    errorMsg.textContent = "Please enter a valid positive number.";
    errorMsg.style.display = "block"; // Show error message
    mileOutput.value = ""; // Clear output
  } else {
    // Clear error message and hide it
    errorMsg.textContent = "";
    errorMsg.style.display = "none";

    // Perform the conversion based on the selected unit
    var km = parseFloat(kmInput.value);
    var convertedValue;

    // Perform the conversion based on the selected unit
    switch(selectedUnit) {
      case "miles":
        convertedValue = km * 0.621371;
        break;
      case "yards":
        convertedValue = km * 1093.61;
        break;
      case "feet":
        convertedValue = km * 3280.84;
        break;
      // Add more cases for additional units as needed
    }

    // Display the result in the output field
    mileOutput.value = convertedValue.toFixed(2);
    
    // Store the converted value in local storage
    var conversionHistory = JSON.parse(localStorage.getItem("conversionHistory")) || [];
    conversionHistory.push({ km: km, convertedValue: convertedValue.toFixed(2), unit: selectedUnit });
    localStorage.setItem("conversionHistory", JSON.stringify(conversionHistory));

    // Update the conversion history display
    displayConversionHistory();
  }
}

// clearing input and output fields
function clearFields() {
  var kmInput = document.getElementById("kmInput");
  var mileOutput = document.getElementById("mileOutput");
  var errorMsg = document.getElementById("errorMsg");

  kmInput.value = "";
  mileOutput.value = "";
  errorMsg.textContent = "";
  errorMsg.style.display = "none"; // Hide error message
}

// theme toggle
function toggleTheme() {
  var body = document.body;
  body.classList.toggle("dark-theme");
}

// displaying conversion history
function displayConversionHistory() {
  var conversionHistory = JSON.parse(localStorage.getItem("conversionHistory")) || [];
  var historyList = document.getElementById("conversionHistoryList");
  historyList.innerHTML = ""; // Clear previous history
  
  // Iterate through conversion history and display in a list
  conversionHistory.forEach(function(item) {
    var listItem = document.createElement("li");
    listItem.textContent = item.km + " km = " + item.convertedValue + " " + item.unit;
    historyList.appendChild(listItem);
  });
}

function clearConversionHistory() {
  localStorage.removeItem("conversionHistory");
  displayConversionHistory();
}
